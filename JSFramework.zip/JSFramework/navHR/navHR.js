$(document).ready(function(){
	navBar=new Object();
	
	
	navBar.make=function(links,containerclass,verticalNav){
	
			var json_links=JSON.parse(links);
			var nav = $("<nav></nav>");
			nav.addClass("navbar navbar-inverse");
	
			var container_div_fluid = $("<div></div>");
			container_div_fluid.addClass("container-fluid");
			
			var navbar_header = $("<div></div>");
			navbar_header.addClass("navbar-header");
			
			var navbar_brand = $("<a></a>").text("WebSiteName");
			navbar_brand.addClass("navbar-brand")
			navbar_brand.attr("href","#");
			
			var navbar_nav_ul = $("<ul></ul>");
			navbar_nav_ul.addClass("nav navbar-nav");
	
	
			for(var i=0;i<json_links.length;i++)
			{
				var li_item=$("<li></li>");
				li_item.addClass("menu"+i)
				li_item.addClass("hrNav");
				if(i==0)
				li_item.addClass("active");
				
				var cls="menu-item"+i
				var li_item_a=$("<a></a>").text(json_links[i].title);
				
				//li_item_a.attr("href",json_links[i].href)
				
				if(json_links[i].subcat!=undefined && json_links[i].subcat.length>0)
				{
					navBar.makeSideBar(json_links[i].subcat,verticalNav,cls);
				}
				
				
				li_item.append(li_item_a);
				navbar_nav_ul.append(li_item);
			}
			navbar_header.append(navbar_brand);
			container_div_fluid.append(navbar_header);
			container_div_fluid.append(navbar_nav_ul);
	
	
		nav.append(container_div_fluid);
		$("."+containerclass).append(nav);
		
		navBar.defaultActiveMenu(json_links);
		
	}
	
	
	
	
	navBar.defaultActiveMenu=function(menus)
	{
		for(var s=0;s<menus.length;s++)
		{
			if(s==0)
			{
				$(".menu"+s).addClass("active");
				$(".menu-item"+s).addClass("show");
			}
			else{
				$(".menu"+s).removeClass("active");
				$(".menu-item"+s).addClass("hide");
			}
		}
	}
	
	navBar.makeSideBar=function(menus,containerclass,cls)
	{
		var menuJson=menus;
		var verticalNav=$("<div></div>");
		verticalNav.addClass(cls);
		verticalNav.addClass("vertical-menu");
		var br=$("<br/>");
		
		for(var x=0;x<menuJson.length;x++)
		{
			var btn = $("<a></a>").text(menuJson[x].title);
			btn.addClass("btn btn-primary");
			verticalNav.append(btn).append(br);
		}
		$("."+containerclass).append(verticalNav);
		
	}
	
	
	navBar.onHRNavClickSubscribe=function(){
		$(".hrNav").click(function(){
			$( ".nav li" ).each(function( index ) {
				$(this).removeClass("active");
				
			});
			$(this).addClass("active");
		});
	}
	
});